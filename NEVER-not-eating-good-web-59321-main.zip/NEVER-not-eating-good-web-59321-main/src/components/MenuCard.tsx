import { Card, CardContent } from '@/components/ui/card';

interface PriceOption {
  label: string;
  price: string;
}

interface MenuCardProps {
  name: string;
  description?: string;
  price?: string;
  priceOptions?: PriceOption[];
  image: string;
}

const MenuCard = ({ name, description, price, priceOptions, image }: MenuCardProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-warm transition-all duration-500 h-full flex flex-col shadow-elegant border-border/50 group">
      <div className="relative h-80 overflow-hidden bg-muted">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110 opacity-90"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>
      <CardContent className="p-8 flex-1 flex flex-col bg-white">
        <h3 className="text-2xl font-display font-light tracking-tight mb-3">{name}</h3>
        <p className="text-muted-foreground mb-6 flex-1 text-sm font-light leading-relaxed">{description}</p>
        
        {priceOptions ? (
          <div className="space-y-3">
            {priceOptions.map((option, index) => (
              <div key={index} className="flex justify-between items-center text-sm border-t border-border/30 pt-3 first:border-t-0 first:pt-0">
                <span className="text-muted-foreground font-light">{option.label}</span>
                <span className="font-normal text-foreground tracking-wide">{option.price}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xl font-light text-foreground tracking-wide">{price}</p>
        )}
      </CardContent>
    </Card>
  );
};

export default MenuCard;
