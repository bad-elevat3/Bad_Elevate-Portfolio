import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ExternalLink } from 'lucide-react';

const Order = () => {
  return (
    <div className="min-h-screen pt-28 pb-20 px-4">
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">Order Online</h1>
          <p className="text-lg text-muted-foreground">
            Choose your preferred delivery platform and get NNEG delivered to your door
          </p>
        </header>

        {/* Delivery Partners */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <Card className="hover:shadow-warm transition-smooth">
            <CardHeader>
              <CardTitle className="text-2xl">UberEats</CardTitle>
              <CardDescription>Fast delivery with live tracking</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Order through UberEats for quick delivery and exclusive deals
              </p>
              <Button className="w-full gradient-hero border-0" size="lg" asChild>
                <a
                  href="https://www.ubereats.com"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Order on UberEats <ExternalLink className="ml-2" size={16} />
                </a>
              </Button>
            </CardContent>
          </Card>

          <Card className="hover:shadow-warm transition-smooth">
            <CardHeader>
              <CardTitle className="text-2xl">Mr D Food</CardTitle>
              <CardDescription>Reliable delivery service</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Order through Mr D Food for great service and special offers
              </p>
              <Button className="w-full gradient-hero border-0" size="lg" asChild>
                <a
                  href="https://www.mrdfood.com"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Order on Mr D <ExternalLink className="ml-2" size={16} />
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Info Section */}
        <Card className="bg-muted">
          <CardContent className="pt-6">
            <h2 className="text-xl font-semibold mb-4">Delivery Information</h2>
            <ul className="space-y-2 text-muted-foreground">
              <li>• Delivery times may vary depending on your location and platform</li>
              <li>• Check each platform for current delivery fees and promotions</li>
              <li>• Both platforms offer contactless delivery options</li>
              <li>• Track your order in real-time through the app</li>
            </ul>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <div className="text-center mt-12 p-8 gradient-hero rounded-lg text-white">
          <h2 className="text-2xl font-display font-bold mb-4">
            Questions about your order?
          </h2>
          <p className="mb-6 opacity-90">
            Get in touch with us and we'll help you out
          </p>
          <Button variant="secondary" size="lg" asChild>
            <a href="/contact">Contact Us</a>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Order;
