import { Card, CardContent } from '@/components/ui/card';
import { Heart, Users, Utensils } from 'lucide-react';
import aboutImage from '@/assets/about-restaurant.jpg';

const About = () => {
  const values = [
    {
      icon: Heart,
      title: 'Made with Love',
      description: 'Every dish is prepared with passion and care, using fresh ingredients',
    },
    {
      icon: Users,
      title: 'Fast Delivery',
      description: 'Quick, convenient delivery bringing restaurant-quality food to your door',
    },
    {
      icon: Utensils,
      title: 'Quality Food',
      description: 'We never compromise on quality, from ingredients to final presentation',
    },
  ];

  return (
    <div className="min-h-screen pt-28 pb-20 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">About NNEG</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Your favorite cloud kitchen - delivering exceptional flavors straight to your door
          </p>
        </header>

        {/* Main Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="space-y-6">
            <h2 className="text-3xl font-display font-bold">Our Story</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              NNEG started with a simple philosophy: life's too short for boring food. As a cloud kitchen, we've reimagined 
              the dining experience - focusing purely on what matters most: exceptional food delivered fresh to your door.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Our menu is a celebration of bold tastes and creative cooking. From our signature wings to our fresh poke bowls, 
              every dish tells a story. We source locally when we can, experiment constantly, and never settle for ordinary.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Whether you're ordering for delivery or pickup, we want you to feel the energy and passion that goes into every plate. 
              Because at NNEG, we're not just serving food - we're creating moments worth savoring, delivered right to you.
            </p>
          </div>

          <div className="relative">
            <img
              src={aboutImage}
              alt="NNEG Cloud Kitchen Food Preparation"
              className="rounded-lg shadow-card w-full h-full object-cover"
            />
            <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-6 rounded-lg shadow-warm max-w-xs">
              <p className="font-display font-bold text-2xl">Never Not Eating Good</p>
              <p className="text-sm opacity-90 mt-2">Since 2024</p>
            </div>
          </div>
        </div>

        {/* Values */}
        <section className="mb-16">
          <h2 className="text-3xl font-display font-bold text-center mb-12">What We Stand For</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <Card key={value.title} className="text-center hover:shadow-warm transition-smooth animate-fade-in" style={{ animationDelay: `${index * 150}ms` }}>
                <CardContent className="pt-8 pb-6">
                  <div className="inline-flex p-4 rounded-full bg-primary/10 mb-4">
                    <value.icon className="text-primary" size={32} />
                  </div>
                  <h3 className="font-semibold text-xl mb-3">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Instagram Feed Section */}
        <section className="text-center bg-muted rounded-lg p-12">
          <h2 className="text-3xl font-display font-bold mb-4">Follow Our Journey</h2>
          <p className="text-muted-foreground mb-8">
            See what's cooking in our kitchen and join our community on Instagram
          </p>
          <a
            href="https://instagram.com/nevernoteatinggood"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block text-primary hover:text-primary-hover font-semibold text-lg transition-smooth"
          >
            @nevernoteatinggood
          </a>
        </section>
      </div>
    </div>
  );
};

export default About;
