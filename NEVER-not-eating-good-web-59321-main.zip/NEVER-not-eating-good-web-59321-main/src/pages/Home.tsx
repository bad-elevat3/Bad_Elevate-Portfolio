import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import MenuCard from '@/components/MenuCard';
import heroImage from '@/assets/hero-food.jpg';
import burgerKoreanChicken from '@/assets/menu/burger-korean-chicken.jpg';
import burgerWaffle from '@/assets/menu/burger-waffle.jpg';
import sidesBBQMac from '@/assets/menu/sides-bbq-mac-cheese.jpg';
import platterVariety from '@/assets/menu/platter-variety.jpg';

const Home = () => {
  const featuredDishes = [
    {
      name: 'Korean Chicken Burger',
      description: 'Our most popular burger with Korean-style flavors',
      image: burgerKoreanChicken,
      priceOptions: [
        { label: 'Burger only', price: 'R120' },
        { label: 'With fries', price: 'R155' },
        { label: 'Combo +4 wings', price: 'R195' },
      ],
    },
    {
      name: 'Waffle Burger',
      description: 'A unique twist with sweet and savory perfection',
      image: burgerWaffle,
      priceOptions: [
        { label: 'Burger only', price: 'R130' },
        { label: 'With fries', price: 'R165' },
        { label: 'Combo +4 wings', price: 'R200' },
      ],
    },
    {
      name: 'BBQ Mac & Cheese',
      description: 'Creamy mac & cheese with BBQ twist',
      price: 'R135',
      image: sidesBBQMac,
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden bg-accent">
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Never Not Eating Good - Premium Burgers"
            className="w-full h-full object-cover opacity-40 mix-blend-overlay"
          />
        </div>

        <div className="relative z-10 text-center text-white px-4 animate-fade-in max-w-4xl mx-auto">
          <h1 className="text-6xl md:text-8xl font-display font-light mb-8 tracking-tight leading-none">
            NEVER NOT<br />EATING GOOD
          </h1>
          <p className="text-lg md:text-xl mb-12 font-light tracking-wide opacity-90">
            Sophisticated flavors, refined taste
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button asChild size="lg" className="bg-white text-black hover:bg-white/90 text-base font-semibold tracking-wide">
              <Link to="/order">
                Order Now
              </Link>
            </Button>
            <Button asChild size="lg" className="bg-white text-black hover:bg-white/90 text-base font-semibold tracking-wide border-2 border-white">
              <Link to="/menu">View Menu</Link>
            </Button>
          </div>
        </div>

        {/* Minimalist Scroll Indicator */}
        <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2">
          <div className="w-px h-16 bg-white/30" />
        </div>
      </section>

      {/* Featured Dishes */}
      <section className="py-32 px-4 gradient-subtle">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-display font-light tracking-tight mb-4">
              Signature Selections
            </h2>
            <div className="w-16 h-px bg-primary mx-auto mb-6" />
            <p className="text-muted-foreground text-base max-w-xl mx-auto font-light">
              Curated favorites that define our craft
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-6xl mx-auto">
            {featuredDishes.map((dish, index) => (
              <div key={dish.name} className="animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
                <MenuCard {...dish} />
              </div>
            ))}
          </div>

          <div className="text-center mt-16">
            <Button asChild size="lg" variant="ghost" className="text-base font-normal tracking-wide group">
              <Link to="/menu">
                Explore Full Menu 
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={18} />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-32 px-4 bg-accent text-white overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={platterVariety}
            alt="NNEG Food Platter"
            className="w-full h-full object-cover opacity-30 mix-blend-overlay"
          />
        </div>
        
        <div className="relative z-10 container mx-auto text-center max-w-3xl">
          <h2 className="text-4xl md:text-6xl font-display font-light mb-8 tracking-tight">
            Ready to elevate<br />your taste?
          </h2>
          <p className="text-base md:text-lg mb-12 opacity-80 font-light max-w-xl mx-auto">
            Available for delivery through UberEats and Mr D
          </p>
          <Button asChild size="lg" className="bg-white text-accent hover:bg-white/90 text-base font-normal tracking-wide px-12">
            <Link to="/order">Place Your Order</Link>
          </Button>
        </div>
      </section>

      {/* Instagram Feed Teaser */}
      <section className="py-24 px-4 bg-white">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-display font-light tracking-tight mb-3">
            Follow the Experience
          </h2>
          <p className="text-muted-foreground mb-10 text-sm tracking-wide">
            @nevernoteatinggood
          </p>
          <Button asChild variant="outline" size="lg" className="font-normal tracking-wide">
            <a
              href="https://instagram.com/nevernoteatinggood"
              target="_blank"
              rel="noopener noreferrer"
            >
              Instagram
            </a>
          </Button>
        </div>
      </section>
    </div>
  );
};

export default Home;
