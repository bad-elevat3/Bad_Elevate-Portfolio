import MenuCard from '@/components/MenuCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Burger Images
import burgerOriginal from '@/assets/menu/burger-original-chicken.jpg';
import burgerKorean from '@/assets/menu/burger-korean-chicken.jpg';
import burgerCheese from '@/assets/menu/burger-chicken-cheese.jpg';
import burgerChickbacon from '@/assets/menu/burger-chickbacon.jpg';
import burgerSmashed from '@/assets/menu/burger-smashed.jpg';
import burgerAnimalStyle from '@/assets/menu/burger-animal-style.jpg';
import burgerWaffle from '@/assets/menu/burger-waffle.jpg';

// Platter Images
import platterOriginal from '@/assets/menu/platter-original.jpg';
import platterKorean from '@/assets/menu/platter-korean.jpg';
import platterVariety from '@/assets/menu/platter-variety.jpg';
import platterWaffle from '@/assets/menu/platter-waffle.jpg';
import platterMixMatch from '@/assets/menu/platter-mix-match.jpg';

// Sides Images
import sidesAnimalFries from '@/assets/menu/sides-animal-fries.jpg';
import sidesMacCheese from '@/assets/menu/sides-mac-cheese.jpg';
import sidesBBQMac from '@/assets/menu/sides-bbq-mac-cheese.jpg';
import sidesWings from '@/assets/menu/sides-cheezy-wings.jpg';

const Menu = () => {
  const menuData = {
    burgers: [
      {
        name: 'Original Chicken',
        image: burgerOriginal,
        priceOptions: [
          { label: 'Burger only', price: 'R105' },
          { label: 'With fries', price: 'R140' },
          { label: 'Combo +4 wings', price: 'R185' },
        ],
      },
      {
        name: 'Korean Chicken',
        image: burgerKorean,
        priceOptions: [
          { label: 'Burger only', price: 'R120' },
          { label: 'With fries', price: 'R155' },
          { label: 'Combo +4 wings', price: 'R195' },
        ],
      },
      {
        name: 'Chicken Cheese',
        image: burgerCheese,
        priceOptions: [
          { label: 'Burger only', price: 'R120' },
          { label: 'With fries', price: 'R155' },
          { label: 'Combo +4 wings', price: 'R195' },
        ],
      },
      {
        name: 'Chickbacon',
        image: burgerChickbacon,
        priceOptions: [
          { label: 'Burger only', price: 'R130' },
          { label: 'With fries', price: 'R160' },
          { label: 'Combo +4 wings', price: 'R200' },
        ],
      },
      {
        name: 'Smashed Burger',
        image: burgerSmashed,
        priceOptions: [
          { label: 'Burger only', price: 'R130' },
          { label: 'With fries', price: 'R165' },
          { label: 'Combo +4 wings', price: 'R200' },
        ],
      },
      {
        name: 'Animal Style SB',
        image: burgerAnimalStyle,
        priceOptions: [
          { label: 'Burger only', price: 'R130' },
          { label: 'With fries', price: 'R165' },
          { label: 'Combo +4 wings', price: 'R200' },
        ],
      },
      {
        name: 'Waffle Burger',
        image: burgerWaffle,
        priceOptions: [
          { label: 'Burger only', price: 'R130' },
          { label: 'With fries', price: 'R165' },
          { label: 'Combo +4 wings', price: 'R200' },
        ],
      },
    ],
    platters: [
      {
        name: 'Original Chicken',
        description: 'All platters come with 2 burgers, 8 wings, and fries',
        image: platterOriginal,
        priceOptions: [
          { label: 'Platter for 2', price: 'R340' },
          { label: 'All You Can Eat', price: 'R395' },
        ],
      },
      {
        name: 'Korean Chicken',
        description: 'All platters come with 2 burgers, 8 wings, and fries',
        image: platterKorean,
        priceOptions: [
          { label: 'Platter for 2', price: 'R350' },
          { label: 'All You Can Eat', price: 'R420' },
        ],
      },
      {
        name: 'Chicken Cheese',
        description: 'All platters come with 2 burgers, 8 wings, and fries',
        image: platterVariety,
        priceOptions: [
          { label: 'Platter for 2', price: 'R350' },
          { label: 'All You Can Eat', price: 'R420' },
        ],
      },
      {
        name: 'Chickbacon',
        description: 'All platters come with 2 burgers, 8 wings, and fries',
        image: platterOriginal,
        priceOptions: [
          { label: 'Platter for 2', price: 'R380' },
          { label: 'All You Can Eat', price: 'R450' },
        ],
      },
      {
        name: 'Smashed Burger',
        description: 'All platters come with 2 burgers, 8 wings, and fries',
        image: platterKorean,
        priceOptions: [
          { label: 'Platter for 2', price: 'R380' },
          { label: 'All You Can Eat', price: 'R450' },
        ],
      },
      {
        name: 'Animal Style SB',
        description: 'All platters come with 2 burgers, 8 wings, and fries',
        image: platterVariety,
        priceOptions: [
          { label: 'Platter for 2', price: 'R380' },
          { label: 'All You Can Eat', price: 'R450' },
        ],
      },
      {
        name: 'Waffle Burger',
        description: 'All platters come with 2 burgers, 8 wings, and fries',
        image: platterWaffle,
        priceOptions: [
          { label: 'Platter for 2', price: 'R380' },
          { label: 'All You Can Eat', price: 'R450' },
        ],
      },
      {
        name: 'Mix & Match',
        description: 'Choose any 2 burgers + 8 wings + fries',
        image: platterMixMatch,
        priceOptions: [
          { label: 'Platter for 2', price: 'R375' },
          { label: 'All You Can Eat', price: 'R445' },
        ],
      },
    ],
    sides: [
      {
        name: 'Animal Style Fries',
        image: sidesAnimalFries,
        price: 'R95',
      },
      {
        name: 'Mac & Cheese',
        image: sidesMacCheese,
        price: 'R90',
      },
      {
        name: 'BBQ Mac & Cheese',
        image: sidesBBQMac,
        price: 'R135',
      },
      {
        name: 'Cheeeezy Wings',
        image: sidesWings,
        priceOptions: [
          { label: 'Wings only', price: 'R100' },
          { label: 'With fries', price: 'R135' },
        ],
      },
    ],
  };

  return (
    <div className="min-h-screen pt-28 pb-20 px-4">
      <div className="container mx-auto">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">Our Menu</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore our carefully crafted dishes made with fresh ingredients and bold flavors
          </p>
        </header>

        {/* Menu Tabs */}
        <Tabs defaultValue="burgers" className="w-full">
          <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-3 mb-12">
            <TabsTrigger value="burgers">Burgers</TabsTrigger>
            <TabsTrigger value="platters">Platters</TabsTrigger>
            <TabsTrigger value="sides">Sides & Extras</TabsTrigger>
          </TabsList>

          <TabsContent value="burgers">
            <div className="mb-6 p-4 bg-muted rounded-lg text-center">
              <p className="text-sm text-muted-foreground">
                All burgers available with 3 options: Burger only | With fries | Combo +4 wings
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {menuData.burgers.map((item, index) => (
                <div key={item.name} className="animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
                  <MenuCard {...item} />
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="platters">
            <div className="mb-6 p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground mb-2">
                <strong>Platter for 2:</strong> Includes 2 burgers, 8 wings, and a portion of fries
              </p>
              <p className="text-sm text-muted-foreground">
                <strong>All You Can Eat:</strong> Includes 2 burgers, 8 wings, fries, MAC&CHEESE + chicken pops
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {menuData.platters.map((item, index) => (
                <div key={item.name} className="animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
                  <MenuCard {...item} />
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="sides">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {menuData.sides.map((item, index) => (
                <div key={item.name} className="animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
                  <MenuCard {...item} />
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Menu;
